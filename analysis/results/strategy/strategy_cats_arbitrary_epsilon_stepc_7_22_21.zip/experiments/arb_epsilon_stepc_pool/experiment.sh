#!/bin/bash

# A script to run one of our experiments in python

# First Make sure the commands are ok in a machine-specific way:
if [ $HOSTNAME == "helmet" ]; then
    function R() { /cygdrive/c/Program\ Files/R/R-3.1.0/bin/R.exe $@; }
    function python() { /cygdrive/c/programs/Python27/python.exe $@; }
fi

if [ $HOSTNAME == "SMG616ALT-1" ]; then
    function R() { /cygdrive/c/Program\ Files/R/R-3.1.0/bin/R.exe $@; }
    function python() { /cygdrive/c/programs/Python27/python.exe $@; }
fi

if [ $HOSTNAME == "smgvickrey.bu.edu" ]; then
    function R() { R $@; }
    function python() { /usr/local/bin/python2.7 $@; }
fi

# Now the rest...

if [ "$#" -lt 2 ]; then
    echo "Usage: experiment.sh {run | analyze} name {arguments}"
    exit 1
fi

if [ "$1" == 'run' ]; then
    program=qpkernel.experiments.$2
    if [ -f qpkernel/experiments/$2.py ]; then
        shift 2
        python -m $program $@
        exit 0
    else
        echo "Unknown file: $program"
        exit 1
    fi
fi

if [ "$1" == 'analyze' ]; then
    program=R/experiments/$2.R
    if [ -f $program ]; then
        echo "running R..."
        shift 2
        R CMD BATCH $program $@
        exit 0
    else
        echo "Unknown file: $program"
        exit 1
    fi
fi

echo "Unknown option $1"
exit 1